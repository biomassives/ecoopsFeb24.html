# NFT Parallax Banner

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/xxpLGKV](https://codepen.io/yudizsolutions/pen/xxpLGKV).

We all know that NFTs are trending nowadays, therefore we have prepared a design that can be used as a banner section of the website, for a better look we have added some animation with the help pf parallax library.

Made by Piyush Kamble from Yudiz